import Admin from "./Admin";
export default Admin;